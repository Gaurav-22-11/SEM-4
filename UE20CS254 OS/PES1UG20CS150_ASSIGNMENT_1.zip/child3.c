#include<stdio.h>
#include <unistd.h>
#include <sys/wait.h>
#include <stdlib.h>
int main()
{
	pid_t pid3;
	printf("\nTHIS IS THE THE CHILD 3 PROCESS %d",getpid());
	return 0;
}
