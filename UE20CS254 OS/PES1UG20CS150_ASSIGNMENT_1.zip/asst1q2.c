#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
#include <stdlib.h>


int main()
{
	pid_t pid1 , pid2 , pid3 , pid4;
	pid1 = fork();
	if(pid1 > 0 )
	{ 
		wait(NULL);
		printf("this is parent with id = %d " , getpid());
		printf("\n");
	}
	else if(pid1 == 0 )
	{ // child
		pid2 = fork();
		if(pid2 > 0)
		{ // THIS IS THE FIRST CHILD PROCESS  
			wait(NULL);
			char *args[]={"./child1",NULL};
        		execvp(args[0],args);
		}
		else if (pid2 == 0 )
		{ //THIS IS SECOND CHILD
			pid3 = fork();
			if(pid3 > 0 )
			{
				wait(NULL); // THIS IS THIRD CHILD
				char *args[]={"./child2",NULL};
        			execv(args[0],args);
			}
			else if(pid3 == 0)
			{
				pid4 = fork();
				if(pid4 > 0)
				{ // THIS IS 4TH CHILD
					wait(NULL);
					char *args[]={"./child3",NULL};
				        execv(args[0],args);
				}
				else if(pid4 == 0)
				{
					char* a[] = {NULL};
					execl("./child4" ,"./child4",NULL);
				}
			}
		}

	}
	else
	{
		printf("failed to create the child processes");
	}
}
