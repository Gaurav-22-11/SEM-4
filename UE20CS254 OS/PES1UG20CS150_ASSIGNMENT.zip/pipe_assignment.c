#include <stdio.h> 
#include <string.h> 
#include <fcntl.h> 
#include <sys/stat.h> 
#include <sys/types.h> 
#include <unistd.h> 

#define buf 100
#define READ_END 0
#define WRITE_END 1

int main()
{
	int count = 0;
	int fd[2];
	pid_t  pid;
    	char writestring[buf]="";
    	char readstring[buf]="";

	if (pipe(fd) == -1) 
	{
		printf("Pipe failed\n");
		return 1;
	}
	pid = fork();
	if (pid > 0)
	{	
        	char c;
        	FILE* fr = fopen("input.txt","r");
		close(fd[READ_END]);
        	int i=0;
        	while ((c=fgetc(fr))!=EOF)
        	{
            		writestring[i]=c;
            		i++;
        	}
		write(fd[WRITE_END], writestring, strlen(writestring)+1);
		close(fd[WRITE_END]);
		//wait(NULL);
	}
	else if (pid == 0) 
	{
		close(fd[WRITE_END]);
		read(fd[READ_END], readstring, buf);
        	printf("Child Process Read : %s\n", readstring);
        	for(int i = 0; readstring[i] != '\0'; i++)
	    	{
			if(readstring[i] == ' ' || readstring[i] == '\n' || readstring[i] == '\t')
		    	{
			    count++;	
		    	} 
	    	}	
	    	printf("\n The Total Number of Words in this String : %d", count);
		close(fd[READ_END]);
	}
	else
	{ 
		printf("Fork failed\n");
		return 1;
	}

}
