#include<stdio.h>
#include <unistd.h>
#include <sys/wait.h>
#include <stdlib.h>
int main()
{
	pid_t pid2;
	printf("\nTHIS IS THE THE CHILD 2 PROCESS %d",getpid());
	return 0;
}
